package iam.aerolinea.servicio;

import iam.aerolinea.modelo.Aeronave;
import iam.aerolinea.modelo.Vuelo;

import java.util.List;

public interface IAeronaveServicio {

}
