package iam.aerolinea.servicio;

import org.springframework.stereotype.Service;

@Service
public class FacturaServicio {
}
