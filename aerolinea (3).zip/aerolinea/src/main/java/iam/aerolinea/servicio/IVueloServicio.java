package iam.aerolinea.servicio;

public interface IVueloServicio {
}
