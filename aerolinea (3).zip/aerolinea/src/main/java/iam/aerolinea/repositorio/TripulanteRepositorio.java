package iam.aerolinea.repositorio;

import org.springframework.stereotype.Repository;

@Repository
public interface TripulanteRepositorio {
}
