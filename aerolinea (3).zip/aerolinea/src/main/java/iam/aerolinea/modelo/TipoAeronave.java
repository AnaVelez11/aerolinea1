package iam.aerolinea.modelo;

public enum TipoAeronave {

    AIRBUSA320,AIRBUSA330,BOEING787;


}
