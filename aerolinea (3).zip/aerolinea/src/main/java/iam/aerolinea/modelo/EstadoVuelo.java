package iam.aerolinea.modelo;

public enum EstadoVuelo {
    A_TIEMPO, RETRASADO, EN_SALA, ABORDANDO, ARRIVADO
}
