package iam.aerolinea.controlador;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class TripulanteControlador {
}
