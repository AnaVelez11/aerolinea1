package iam.aerolinea.controlador;

public class SeguridadControlador {
}
